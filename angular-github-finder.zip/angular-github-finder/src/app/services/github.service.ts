import {Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
    providedIn: 'root'
  })
export class GithubService{
    private username = '';
    private client_id = '03487a8c85b8376f0d00';
    private client_secret='4d5763c3b8c10108b5df3d43372c556923272a4c';
    
    constructor(private _http:HttpClient){
        console.log('Github Service Init...');
    }
    
    getUser():Observable<any>{
        return this._http.get<any>('https://api.github.com/users/'+this.username+'?client_id='+this.client_id+'&client_secret='+this.client_secret);
           
    }
    
    getRepos():Observable<any>{
        return this._http.get<any>('https://api.github.com/users/'+this.username+'/repos?client_id='+this.client_id+'&client_secret='+this.client_secret);
          
    }
    
    updateUsername(username:string){
        this.username = username;
    }
}
